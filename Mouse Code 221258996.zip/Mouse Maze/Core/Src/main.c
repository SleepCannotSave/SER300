/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
GPIO_TypeDef* MOTOR1_GPIO_PORT = GPIOB;
uint16_t MOTOR1_GPIO_PIN = GPIO_PIN_5;

GPIO_TypeDef* MOTOR2_GPIO_PORT = GPIOB;
uint16_t MOTOR2_GPIO_PIN = GPIO_PIN_6;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define __VREFANALOG_VOLTAGE_ 3300
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
char *demo_string = "Stopped\r\n"; //Start String
char *Maze1_string = "Starting Maze 1\r\n"; //String to transmit after starting maze 1
//char *Causeway_string = "Starting Causeway\r\n"; //String to transmit after starting Causeway
char *Turn_Right_string = "LED3 will illuminate if mouse has open path to the right\r\n";
//char *Maze2_string = "Starting Maze 2\r\n"; //String to transmit after starting maze 2
char *Turn_Around_string = "LED3 will illuminate if mouse should turn around\r\n";
//char *Spiral_string = "Starting Spiral\r\n"; //String to transmit after starting spiral
char *Edge_Detected_string = "LED3 will illuminate if mouse detects edge on right or left\r\n";
char *Finish_string = "End Reached\r\n"; //String to transmit after reaching the end
uint8_t recv_char; // String recieved from BT module
char recv_str[20]; // String is written here one char at a time
//char txBuf[30];//Testing use
int i=0;
int d=0;
enum States State; // Sets the state variable to be used with enum States
const int Base_Speed = 30000; //Adujust to control the base speed when driving forwards
int Turn_Speed = Base_Speed/2; //Half of driving speed to be used for turning
int direction; //For use in the set motor speed function
int Forward = GPIO_PIN_RESET; // Adding these to make it easier for myself to understand which way i'm trying to turn motors
int Reverse = GPIO_PIN_SET; // As above
// Variables that the adc values will be written to and then checked against
uint16_t Front;
uint16_t Right;
uint16_t Left;
volatile uint16_t adcResultsDMA [3]; //Array to hold the DMA adc values
const int adcChannelCount = sizeof (adcResultsDMA) / sizeof (adcResultsDMA[0]); //gives the num of adc channels from the above array
volatile int adcConvComplete = 0; //Set by callback
int posM1 = 0; // Count of pulses on motor 1 encoder
int posM2 = 0; // Count of pulses on motor 2 encoder
volatile int motor_L_speed = Base_Speed; // For use with PID
volatile int motor_R_speed = Base_Speed;
int Kp = 1; //Proportional constant
int Ki = 0; //Integral constant
int Kd = 0; //Derivative constant
int PulsePerRotation = 700;
int Sent = 0;//Used so messages only get sent once
//volatile uint16_t M1C2; //is
//volatile uint16_t M2C2;

enum States { //Holds the states that the mouse could be in
	Stop,
	Start,
	Causeway,
	Maze2,
	Spiral,
	Finish
};

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM1_Init(void);
/* USER CODE BEGIN PFP */

void Forward_Move()
{
	//Restart PWM signal if they were stopped
	  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
	  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
TIM1->CCR1 = 91.2; //Set compare value for channel 1 pwm
TIM1->CCR2 = 93.41;//Set compare value for channel 2 pwm
}
void Right_Turn()
{
	TIM1->CCR1 = 100;
	  HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_2);//Disables channel 2 pwm to stop wheel
	TIM1->CCR2 = 0;
}
void Left_Turn()
{
	  HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);//Disables channel 1 pwm to stop wheel
	TIM1->CCR1 = 0;
	TIM1->CCR2 = 100;
}
void Stop_Move()
{
	//Stops both pwm channels to stop both motors
	HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);
	HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_2);
}
//void Motor_SetSpeed(TIM_HandleTypeDef *htim, uint32_t channel, uint32_t pulse, GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, uint8_t direction)
//    {
//
//	  TIM_OC_InitTypeDef sConfigOC = {0};
//
//    	    sConfigOC.OCMode = TIM_OCMODE_PWM1;
//    	    sConfigOC.Pulse = pulse;  // Adjust as needed
//    	    sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
//    	    sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
//    	    HAL_TIM_PWM_ConfigChannel(htim, &sConfigOC, channel);
//    	    HAL_TIM_PWM_Start(htim, channel);
//
//    	    // Set the GPIO pin high or low based on the direction
//    	    HAL_GPIO_WritePin(GPIOx, GPIO_Pin, direction);
//    	}

//void Motor_SetSpeed(uint32_t pulse, GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, uint8_t direction)
//  {
//		TIM1->CCR1 = pulse;
//		TIM1->CCR2 = pulse;
//		// Set the GPIO pin high or low based on the direction
//		HAL_GPIO_WritePin(GPIOx, GPIO_Pin, direction);
//  	}
//void Motor_adjustSpeed(int motor_R_speed, int motor_L_speed)
//{
//	TIM1->CCR1 = motor_R_speed;
//	TIM1->CCR2 = motor_L_speed;
//}

//void Motors_Stop()
//{
//	Motor_adjustSpeed(0,0);
//	posM1=0;
//	posM2=0;
//}


//void Motor_SetSpeed(TIM_HandleTypeDef *htim, uint32_t channel, uint32_t pulse, GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, uint8_t direction)
//  {
//
//	  TIM_OC_InitTypeDef sConfigOC = {0};
//
//  	    sConfigOC.OCMode = TIM_OCMODE_PWM1;
//  	    sConfigOC.Pulse = pulse;  // Adjust as needed
//  	    sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
//  	    sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
//  	    HAL_TIM_PWM_ConfigChannel(htim, &sConfigOC, channel);
//  	    HAL_TIM_PWM_Start(htim, channel);
//
//  	    // Set the GPIO pin high or low based on the direction
//  	    HAL_GPIO_WritePin(GPIOx, GPIO_Pin, direction);
//  	}
//
//  void Motors_Forward()
//  {
//
//  	  Motor_SetSpeed(&htim1, TIM_CHANNEL_1, 30000, MOTOR1_GPIO_PORT, MOTOR1_GPIO_PIN, GPIO_PIN_SET);
//  	  Motor_SetSpeed(&htim1, TIM_CHANNEL_2, 65000, MOTOR2_GPIO_PORT, MOTOR2_GPIO_PIN, GPIO_PIN_SET);
//  }
//
//  void Motors_Stop()
//  {
//  	  Motor_SetSpeed(&htim1, TIM_CHANNEL_1, 0, MOTOR1_GPIO_PORT, MOTOR1_GPIO_PIN, GPIO_PIN_SET);
//  	  Motor_SetSpeed(&htim1, TIM_CHANNEL_2, 0, MOTOR2_GPIO_PORT, MOTOR2_GPIO_PIN, GPIO_PIN_SET);
//  }
//
////void Motors_ForwardHalf()
//{
//	posM1=0;
//	posM2=0;
//	Motor_SetSpeed(Base_Speed, GPIOB, GPIO_PIN_6, Forward);
//	Motor_SetSpeed(motor_L_speed, GPIOB, GPIO_PIN_5, Forward);
//	while (!(posM1 < 350))//Goes forward approx half a cell
//	{
//		Motors_Stop();
//	}
//}

//void Motors_Forward1()
//{
//	posM1=0;
//	posM2=0;
//	Motor_SetSpeed(Base_Speed, GPIOB, GPIO_PIN_6, Forward);
//	Motor_SetSpeed(motor_L_speed, GPIOB, GPIO_PIN_5, Forward);
//	while (posM1 < 700 || Forward < 2000)//Goes forward approx 1 cell but stops if the front sensor detects a wall
//	{
//		//Keep Going
//	}
//	Motors_Stop();
//}

//void Motors_Finish()
//{
//	posM1=0;
//	posM2=0;
//	Motor_SetSpeed(Base_Speed, GPIOB, GPIO_PIN_6, Forward);
//	Motor_SetSpeed(motor_L_speed, GPIOB, GPIO_PIN_5, Forward);
//	while (posM1 < 700 || !(Forward > 4000 && Left > 4000 && Right > 4000))//Goes forward approx 1 cell but stops if the front sensor detects a wall
//	{
//		//Keep Going
//	}
//	Motors_Stop();
//}
//
//void TurnRight()
//{
//	while (posM1>-354)
//	{
//	Motor_SetSpeed(Turn_Speed, GPIOB, GPIO_PIN_6, Reverse);
//	Motor_SetSpeed(Turn_Speed, GPIOB, GPIO_PIN_5, Forward);
//	}
//	Motors_Stop();
//}

//void TurnLeft()
//{
//
//	Motor_SetSpeed(Turn_Speed, GPIOB, GPIO_PIN_7, Reverse);
//	Motor_SetSpeed(Turn_Speed, GPIOB, GPIO_PIN_5, Forward);
//}


//
//void PController(int Expected,int Measured)
//{
//motor_L_speed = Base_Speed + Kp*(Expected-Measured); //Kp set as variable for easy editing
//if (motor_L_speed > 65535)
//{
//	motor_L_speed = 65535;
//}
//Motor_adjustSpeed(motor_R_speed,motor_L_speed);
//}

//void ReadADC()
//{
//	  Front=adcResultsDMA[1];
//	  Left=adcResultsDMA[0];
//	  Right=adcResultsDMA[2];
//	  adcConvComplete=0;
//}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */
  State = Stop;
  HAL_UART_Receive_IT(&huart2, &recv_char, 1); //UART2 Interrupt call

  if (HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED) != HAL_OK)//Calibrates ADC
  {
	  Error_Handler();
  }

  //Start Timer2 to trigger ADC and start ADC in DMA mode

	HAL_ADC_Start_DMA(&hadc1, (uint32_t *)adcResultsDMA, adcChannelCount);//Starts the adc conversion
	HAL_TIM_Base_Start(&htim2);//Starts Timer 2 to trigger adc conversions
	  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);//Start TIM1 channel 1 pwm
	  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);//Start TIM1 channel 2 pwm
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
	  while (adcConvComplete != 1) // Runs other code while ADC is converting
	  {
	  	if (Left>3800 && Right>3800)// checks if the mouse has reached the end of the spiral and both sensors detect the edge at once
	  		{
	  		Stop_Move(); // Stops moving
	  		}
	  	if (Right > 2000)//Checks the right sensor to detect the edge
	  		{
	  		Left_Turn();// Turns towards the left as long as the right sensor detects the edge
	  //		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, SET); //Testing code
	  		}
	  	else if (Left > 2100)//Checks the left sensor to detect the edge
	  		{
	  		Right_Turn();//Turns right as long as the left edge is detected
	  //		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, RESET); //Testing code
	  		}
	  	Forward_Move();//Moves forward if no edges are detected
	  }
	  Right = adcResultsDMA[0];//Writes the first adc channel value to the Right var
	  Left = adcResultsDMA[2];//Writes the third adc channel value to the Left var
	  adcConvComplete=0;//Unsets the adc conversion flag
	  HAL_ADC_Start_DMA(&hadc1, (uint32_t *)adcResultsDMA, adcChannelCount);// Restarts the adc

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 40;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }

  /** Enable MSI Auto calibration
  */
  HAL_RCCEx_EnableMSIPLLMode();
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.NbrOfConversion = 3;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_EXTERNALTRIG_T2_TRGO;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_6;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_2CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = ADC_REGULAR_RANK_2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_10;
  sConfig.Rank = ADC_REGULAR_RANK_3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 32-1;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 100-1;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.BreakFilter = 0;
  sBreakDeadTimeConfig.Break2State = TIM_BREAK2_DISABLE;
  sBreakDeadTimeConfig.Break2Polarity = TIM_BREAK2POLARITY_HIGH;
  sBreakDeadTimeConfig.Break2Filter = 0;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 64;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 12500-1;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_ENABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, FIRCTRL_Pin|RIRCTRL_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LD3_Pin|LIRCTRL_Pin|M2DIR_Pin|GPIO_PIN_6, GPIO_PIN_RESET);

  /*Configure GPIO pin : LMINT_Pin */
  GPIO_InitStruct.Pin = LMINT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(LMINT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : M1COUNT_Pin */
  GPIO_InitStruct.Pin = M1COUNT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(M1COUNT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : RMINT_Pin */
  GPIO_InitStruct.Pin = RMINT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(RMINT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : M2COUNT_Pin */
  GPIO_InitStruct.Pin = M2COUNT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(M2COUNT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : FIRCTRL_Pin RIRCTRL_Pin */
  GPIO_InitStruct.Pin = FIRCTRL_Pin|RIRCTRL_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LD3_Pin LIRCTRL_Pin */
  GPIO_InitStruct.Pin = LD3_Pin|LIRCTRL_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : M2DIR_Pin PB6 */
  GPIO_InitStruct.Pin = M2DIR_Pin|GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);

  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){//Receives Bluetooth transmission and sets state accordingly
    if(huart->Instance == USART2 ){
        if(recv_char == '\r'){

	    //HAL_UART_Transmit(&huart2, recv_str, i, HAL_MAX_DELAY);

		if(!strcmp(recv_str, "0")){
//		    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, SET);
		    State = Stop;
		    d=0;
		}
		if(!strcmp(recv_str, "1")){
//		    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, RESET);
		    State = Start;
		    d=0;
	        }
		if(!strcmp(recv_str, "2")){
		    State = Causeway;
		    d=0;
		}
		if(!strcmp(recv_str, "3")){
//		    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, SET);
		    State = Maze2;
		    d=0;
		}
		if(!strcmp(recv_str, "4")){
//		    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, RESET);
		   State = Spiral;
		   d=0;
		}

		memset(recv_str, 0, i);
		i=0;
		}else{
		    if(recv_char == '\r' || recv_char == '\n'){
		} else{
		    recv_str[i++] = recv_char;
		}
	 }
	 HAL_UART_Receive_IT(&huart2, &recv_char, 1); //UART2 Interrupt call

    }
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
    {
	adcConvComplete=1; //Sets adc conversion complete flag
	HAL_ADC_Stop_DMA(&hadc1); //Stops adc from converting
    }

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) // function to read encoder and increment or decrement position count based on second pin
{
//	switch(GPIO_Pin)
//	{
//	case LMINT_Pin :
////	  M1C2 = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_7);
//	  if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_7)==0)
//	  {
//		  posM1++;
//	  }
//	  else
//	  {
//		  posM1--;
//	  }
//	  break;
//	case RMINT_Pin :
////		M2C2 = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1);
//		  if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1)==0)
//		  {
//			  posM2--;
//		  }
//		  else
//		  {
//			  posM2++;
//		  }
//		  break;
//	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
